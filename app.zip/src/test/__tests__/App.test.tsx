import React from 'react'
import { shallow, render } from 'enzyme'

it('renders learn react link', () => {
  const app = render(<div> Name </div>)

  expect(app).toMatchSnapshot()
})

it('renders learn react link', () => {
  const app = shallow(<div />)

  expect(app).toMatchSnapshot()
})
