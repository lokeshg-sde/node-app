/* eslint-disable @typescript-eslint/explicit-module-boundary-types,  @typescript-eslint/no-unused-vars */

import React from 'react'
import './AppStyles.css'

import Grid from './components/GridContainer'
import DropDown from './components/DropDown'
import NestedList from './components/DropDownList'

function App() {
  return (
    <>
      {' '}
      <Grid />
      {/* <DropDown /> */}
    </>
  )
}

export default App
