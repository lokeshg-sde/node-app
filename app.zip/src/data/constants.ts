import PeopleAltIcon from '@material-ui/icons/PeopleAlt'
import PinDropIcon from '@material-ui/icons/PinDrop'
import AccountCircleIcon from '@material-ui/icons/AccountCircle'
import LocationCityIcon from '@material-ui/icons/LocationCity'
import ShowChartIcon from '@material-ui/icons/ShowChart'
import HomeWorkIcon from '@material-ui/icons/HomeWork'

import RealEstate from '../Icons/RealEstate'
import RoomIcon from '../Icons/Room'
import Space from '../Icons/Space'
import Forecast from '../Icons/Forecast'

const cardSections = [
  {
    id: 'people',
    section: 'People',
    label: 'Manage your employee records',
    column: 1,
    menuItems: [
      {
        // id: 'peopleReports',
        title: 'People Reports',
        subtitle: 'Manage your employee records',
        Icon: PeopleAltIcon,
        iconColor: '#FA5723',
        isExpandable: true,
      },
    ],
  },
  {
    id: 'realEstate',
    section: 'Real Estate',
    label: 'View your portfolio',
    column: 1,
    menuItems: [
      {
        // id: '',
        title: 'Real Estate',
        subtitle: 'View your real estate portfolio and related costs',
        Icon: RealEstate,
        iconColor: '#4C80BF',
        isExpandable: true,
      },
    ],
  },
  {
    id: 'booking',
    section: 'Booking',
    label: 'Monitor workplace bookings',
    column: 1,
    menuItems: [
      {
        // id: ,
        title: 'Desk Booking',
        subtitle: 'Get insight into how desk booking is being used',
        Icon: PinDropIcon,
        iconColor: '#00B572',
        isExpandable: true,
      },
      {
        // id: ,
        title: 'Room Booking Dashboard',
        subtitle: 'Get insight into how room booking is being used',
        Icon: RoomIcon,
        iconColor: '#00B572',
        isExpandable: false,
      },
    ],
  },
  {
    id: 'utilization',
    section: 'Utilization',
    label: 'See how your workplace is being used',
    column: 2,
    menuItems: [
      {
        // id: ,
        title: 'Space',
        subtitle: 'Understand how your space is used',
        Icon: Space,
        iconColor: '#278FB6',
        isExpandable: true,
      },
      {
        // id: ,
        title: 'Occupancy',
        subtitle: 'See current occupancy across your workplaces',
        Icon: AccountCircleIcon,
        iconColor: '#278FB6',
        isExpandable: true,
      },
      {
        // id: ,
        title: 'Custom Analytics',
        subtitle: 'See customized workplace reports',
        Icon: ShowChartIcon,
        iconColor: '#278FB6',
        isExpandable: true,
      },
    ],
  },
  {
    id: 'workplace',
    section: 'Workplace',
    label: 'Manage your workplace',
    column: 2,
    menuItems: [
      {
        // id: ,
        title: 'Facilities',
        subtitle:
          'View and edit information related to seats, rooms and utilities',
        Icon: LocationCityIcon,
        iconColor: '#3F51B5',
        isExpandable: true,
      },
      {
        // id: ,
        title: 'Neighborhoods',
        subtitle: 'See reports that help manage your neighborhoods',
        Icon: LocationCityIcon, //
        iconColor: '#3F51B5',
        isExpandable: true,
      },
    ],
  },
  {
    id: 'planning',
    section: 'Planning',
    label: 'Plan your space needs',
    column: 3,
    menuItems: [
      {
        // id: ,
        title: 'Seating Needs',
        subtitle:
          'Assign and track seating needs for your employees, and compare to seating availability',
        Icon: HomeWorkIcon,
        iconColor: '#97CE5F',
        isExpandable: false,
      },
      {
        // id: ,
        title: 'Forecast',
        subtitle:
          'Plan for future growth and anticipate when your facilities will exceed capacity',
        Icon: Forecast,
        iconColor: '#97CE5F',
        isExpandable: false,
      },
      {
        // id: ,
        title: 'Space Planning Needs',
        subtitle:
          'Track open reqs and compare against head counts and capacity',
        Icon: Forecast, //
        iconColor: '#97CE5F',
        isExpandable: false,
      },
    ],
  },
]

export default cardSections
