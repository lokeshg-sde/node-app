/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable @typescript-eslint/explicit-module-boundary-types,  @typescript-eslint/no-unused-vars */

import React, { useMemo } from 'react'
import compact from 'lodash/compact'
import useMediaQuery from '@material-ui/core/useMediaQuery'

import reportDefinitions from './constants'

function useQuery(query: string): boolean {
  return useMediaQuery<boolean>(query)
}

export default function useGridData() {
  const match = useQuery('(min-width:965px)')
  const secondMatch = useQuery('(max-width:965px)')
  const matches = useQuery('(min-width:652px)')

  return useMemo(() => {
    // React.useMemo()
    const gridData: any = []

    reportDefinitions.forEach((item: any) => {
      if (match) {
        if (!gridData[item.column - 1]) {
          gridData[item.column - 1] = []
        }

        gridData[item.column - 1].push(item)
      } else if (secondMatch && matches) {
        if (item.column === 1 || item.column === 3) {
          if (!gridData[0]) {
            gridData[0] = []
          }

          gridData[0].push(item)
        } else {
          if (!gridData[1]) {
            gridData[1] = []
          }

          gridData[1].push(item)
        }
      } else {
        if (!gridData[0]) {
          gridData[0] = []
        }

        gridData[0].push(item)
      }
    })

    return compact(gridData)
  }, [matches, secondMatch, match])
}
