/* eslint-disable @typescript-eslint/explicit-module-boundary-types,  @typescript-eslint/no-unused-vars, react/prop-types */

import React from 'react'
import TextField from '@material-ui/core/TextField'
import ExpandMoreIcon from '@material-ui/icons/ExpandMore'

import Autocomplete from '@material-ui/lab/Autocomplete'

export default function ComboBox() {
  return (
    <Autocomplete
      getOptionLabel={(option) => option.title}
      id="combo-box-demo"
      options={[{ title: 'Option' }, { title: 'label' }]}
      popupIcon={<ExpandMoreIcon color="primary" />}
      renderInput={(params) => (
        <TextField {...params} label="Combo box" variant="outlined" />
      )}
      style={{ width: 300 }}
    />
  )
}
