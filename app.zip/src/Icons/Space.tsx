// The following eslint-disable was automated from the ts conversion
/* eslint-disable @typescript-eslint/no-explicit-any,@typescript-eslint/explicit-module-boundary-types,@typescript-eslint/no-unused-vars,max-len */
import React from 'react'
import SvgIcon from '@material-ui/core/SvgIcon'

type Props = {
  color?: any
}
export default function Space({ color, ...rest }: Props) {
  return (
    <SvgIcon {...rest} viewBox="0 0 16 20">
      <path d="M7 2V7H6V2H2V10H6V9H7V14H6V11H2V16H9V14H10V16H16V14H18V18H0V0H18V12H16V7H10V12H9V6H16V2H7Z" />
    </SvgIcon>
  )
}
