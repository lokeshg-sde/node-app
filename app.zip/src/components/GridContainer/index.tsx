/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable @typescript-eslint/explicit-module-boundary-types,  @typescript-eslint/no-unused-vars */
import React from 'react'
import { makeStyles } from '@material-ui/core/styles'
import Paper from '@material-ui/core/Paper'
import Grid from '@material-ui/core/Grid'

import DropDownList from '../DropDownList'
import useGridData from '../../data/useGridData'

const useStyles = makeStyles((theme) => ({
  root: {
    flexGrow: 1,
    padding: '10px',
    paddingLeft: '20px',
  },
  paper: {
    padding: theme.spacing(1),
    textAlign: 'center',
    color: theme.palette.text.secondary,
  },
}))

type GridColumnWidth = 4 | 6 | 12

const getWidth = (length: number): GridColumnWidth => {
  if (length === 3) {
    return 4
  } else if (length === 2) {
    return 6
  }
  return 12
}

export default function CenteredGrid() {
  const classes = useStyles()
  const data = useGridData()
  const width: GridColumnWidth = getWidth(data.length)

  return (
    <div className={classes.root}>
      <Grid
        alignItems="stretch"
        container
        direction="row"
        justifyContent="space-evenly"
        spacing={2}
        xs={12}
      >
        {data.map((item: any, index: number) => (
          <Grid key={index} item spacing={2} xs={width}>
            {item.map((section: any, index: number) => (
              <DropDownList key={index} props={section} />
            ))}
          </Grid>
        ))}
      </Grid>
    </div>
  )
}
