/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable @typescript-eslint/explicit-module-boundary-types,  @typescript-eslint/no-unused-vars, react/prop-types */

import React, { useState } from 'react'
import { makeStyles, Theme, createStyles } from '@material-ui/core/styles'
import ListSubheader from '@material-ui/core/ListSubheader'
import Paper from '@material-ui/core/Paper'
import List from '@material-ui/core/List'
import ListItem from '@material-ui/core/ListItem'
import ListItemIcon from '@material-ui/core/ListItemIcon'
import ListItemText from '@material-ui/core/ListItemText'
import Collapse from '@material-ui/core/Collapse'
import InboxIcon from '@material-ui/icons/MoveToInbox'
import DraftsIcon from '@material-ui/icons/Drafts'
import SendIcon from '@material-ui/icons/Send'
import ExpandLess from '@material-ui/icons/ExpandLess'
import ExpandMore from '@material-ui/icons/ExpandMore'
import StarBorder from '@material-ui/icons/StarBorder'

const useStyles = makeStyles((theme: Theme) =>
  createStyles({
    container: {
      padding: 10,
    },
    root: {
      width: '100%',
      backgroundColor: theme.palette.background.paper,
    },
    textItem: {
      display: 'flex',
      alignItems: 'flex-start',
      flexDirection: 'column',
      fontStyle: 'normal',
      fontFamily: 'Open Sans',
    },
    itemTitle: {
      fontFamily: 'Open Sans',
      fontSize: '15px',
      lineHeight: '24px',
      color: '#212121',
      fontWeight: 600,
    },
    muiTypographyBody: {
      fontWeight: 600,
    },
    itemInfo: {
      fontWeight: 'normal',
      fontSize: '12px',
      lineHeight: '16px',
      color: '#757575',
    },
    nested: {
      paddingLeft: theme.spacing(4),
    },
    icon: {
      color: 'red',
    },
    listIcon: {
      marginRight: 0,
    },
    iconColor: {
      color: 'green',
    },
    subHeader: {
      textAlign: 'left',
    },
    paper: {
      padding: theme.spacing(1),
      textAlign: 'center',
      color: theme.palette.text.primary,
    },
  }),
)

const useIconStyle = (color: string) => {
  return makeStyles((theme: Theme) =>
    createStyles({
      root: {
        color: color,
      },
    }),
  )()
}

export default function NestedList({ props }: any) {
  const classes = useStyles()
  const [open, setOpen] = useState(false)
  const { menuItems } = props

  const handleClick = () => {
    setOpen(!open)
  }

  return (
    <div className={classes.container}>
      <div> {props.label} </div>
      {menuItems.map((menu: any, index: number) => {
        const { Icon, title, isExpandable, subtitle, iconColor } = menu
        const styles = useIconStyle(iconColor)

        return (
          <Paper key={index} className={classes.paper}>
            <List
              aria-labelledby="nested-list-subheader"
              className={classes.root}
              component="nav"
            >
              <ListItem
                button
                onClick={isExpandable ? handleClick : () => null}
                // onMouseLeave={() => setOpen(false)}
                // onMouseOver={isExpandable ? () => setOpen(true) : () => null}
              >
                <ListItemIcon>
                  <Icon
                    classes={{
                      root: styles.root,
                    }}
                  />
                </ListItemIcon>
                <ListItem
                  classes={{
                    root: classes.textItem,
                  }}
                >
                  <ListItemText
                    classes={{
                      root: classes.itemTitle,
                      // dense: classes.muiTypographyBody,
                    }}
                    primary={title}
                    disableTypography
                  />
                  <ListItemText
                    classes={{
                      root: classes.itemInfo,
                    }}
                    primary={subtitle}
                  />
                </ListItem>
                <ListItemIcon
                  classes={{
                    root: classes.listIcon,
                  }}
                >
                  {isExpandable && (open ? <ExpandLess /> : <ExpandMore />)}
                </ListItemIcon>
              </ListItem>
              {isExpandable && (
                <Collapse in={open} timeout="auto" unmountOnExit>
                  <List component="div" disablePadding>
                    <ListItem button className={classes.nested}>
                      <ListItemIcon>
                        <StarBorder
                          classes={{
                            root: classes.iconColor,
                          }}
                        />
                      </ListItemIcon>
                      <ListItemText primary="Starred" />
                    </ListItem>
                  </List>
                  <List component="div" disablePadding>
                    <ListItem button className={classes.nested}>
                      <ListItemIcon>
                        <DraftsIcon
                          classes={{
                            root: classes.iconColor,
                          }}
                        />
                      </ListItemIcon>
                      <ListItemText primary="Trash" />
                    </ListItem>
                  </List>
                </Collapse>
              )}
            </List>
          </Paper>
        )
      })}
    </div>
  )
}
