/* eslint-disable @typescript-eslint/explicit-module-boundary-types,  @typescript-eslint/no-unused-vars */
import React from 'react'
import SvgIcon from '@material-ui/core/SvgIcon'

export default function Room({ ...rest }) {
  return (
    <SvgIcon
      width="32"
      height="33"
      viewBox="0 0 32 33"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        d="M18.2319 2.66687L6.63768 4.90529V4.98589V27.0166V27.126L18.2319 29.3356V27.0166H24.029V4.98589H18.2319V2.66687ZM18.2319 24.4075V7.59461H21.7105V24.4075H18.2319Z"
        fill="#00B572"
      />
    </SvgIcon>
  )
}
